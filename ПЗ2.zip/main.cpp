#include <iostream>
#include <cmath>
#include <sstream>
#include <string>

 
int main()
{
  int i, c = 0;
  std :: string b;
  std :: cin >> i;
  std :: cout << i << "=";
  while (abs(i) > 0) {
    if (i % 10 != 0){
      b = std :: to_string(abs(i) % 10) + "*10^" + std :: to_string(c) + b;
      if (i>0) b = "+"+b;
      else b = "-"+b;
    }
    c++;
    i = i / 10;
  }
  std :: cout << b;
  return 0;

}